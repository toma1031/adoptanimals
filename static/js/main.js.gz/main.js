// flatpickr('#id_request_date_from', {
//   minDate: "today"
// });

// flatpickr('#id_request_date_to', {
//   minDate: "today"
// });